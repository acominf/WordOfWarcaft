import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Vidas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Vidas extends Actor
{
    private String sNameFile;
    public Vidas(String sNameF){    
        this.sNameFile=sNameF;
        setImage(sNameFile+".png");
    }
    
    public void act()
    {
        
    }
   
}