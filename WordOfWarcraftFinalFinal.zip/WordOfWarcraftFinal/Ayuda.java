import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ayuda here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ayuda extends Boton
{
 public Ayuda(StarScreen M){
        super(M);// una variable de tipo StarScreen llamada desde Boton
    }
    public void act() 
    {
        if(Greenfoot.mouseClicked(this)){// si es clickeado esre objeto llama al método ayuda de boton
            super.ayuda();
    }   
}
}