import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class StarScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StarScreen extends World 
{

    /**
     * Constructor for objects of class StarScreen.
     * 
     */
    Jugar bjugar = new Jugar(this);
    Ayuda bayuda = new Ayuda(this);
    Creditos bcreditos = new Creditos(this);
    /*private Boton botAyuda;
    private Boton botCreditos;
    private Boton botJugar;*/
    private GreenfootImage aiu;
    private GreenfootImage cred;
    private GreenfootImage men;
    private MyWorld Mundo;
    int iBand = 0;
    public StarScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1080, 600, 1);
        Mundo = new MyWorld(1);
        addObject(bjugar,810,550);
        addObject(bayuda,270,550);
        addObject(bcreditos,540,550);
        aiu = new GreenfootImage("aiuda.png");
        cred = new GreenfootImage("credit.png");
        men = new GreenfootImage("2408.jpg");
        int iBand = 0;  
    }
     /**
      * Metodo Act de StarScreen.
      * En este metodo se encarga de administrar el menu principal.
      */
    public void act()
    {
        if(Greenfoot.isKeyDown("enter"))
        {
            addObject(bjugar,810,550);
            addObject(bayuda,270,550);
            addObject(bcreditos,540,550);

            setBackground(men);
            iBand = 0;
            showText("                                      ",200,20);
        }
        if(iBand == 1)
        {
            showText("Preciona ENTER para regresar al menu ",200,20);
        }
        
    }
    public void jugar(){
        Greenfoot.setWorld(Mundo);
    }
    public void ayuda(){
            setBackground(aiu);
            removeObject(bayuda);
            removeObject(bcreditos);
            removeObject(bjugar);
            iBand = 1;
    }
    public void creditos(){
            setBackground(cred);
            removeObject(bayuda);
            removeObject(bcreditos);
            removeObject(bjugar);
            iBand = 1;
        
    }
}
