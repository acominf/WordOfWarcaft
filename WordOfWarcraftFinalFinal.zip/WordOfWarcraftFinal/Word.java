import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.*;
import java.util.*;
import java.util.HashMap;
import java.io.FileNotFoundException;
/**
 * Write a description of class Word here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Word
{
    private String s1;
    private HashMap<Integer,String> listaPalabras = new HashMap<Integer,String>();
    
   public Word() //throws FileNotFoundException
   {/*
        File file = new File("WordLevel1.txt");
        //initialize the scanner
        Scanner scan = new Scanner(file);
        ;
        // iterate through the file line by line
        while(scan.hasNextLine())
        {
         // print the contents of a file by line
         s1 = scan.nextLine();
         listaPalabras.put(i, s1);
         i++;
        }
            // close the scanner object;
            scan.close();*/
        int i = 0;
        try
        {
           StringBuffer txt = new StringBuffer();
           
           //Abrir el fichero indicado en la variable nombreFichero
           FileReader fr = new FileReader("WordLevel1.txt");
           //Leer el primer carácter
           //Se debe almacenar en una variable de tipo int
           int caract = fr.read();
           //Se recorre el fichero hasta encontrar el carácter -1
           //   que marca el final del fichero
           while(caract != -1)
           {
               if((char)caract != '\n')
               {
                   txt.append((char)caract);
               }
               else
                  if((char)caract == '\n')
                  {
                     /**
                     * La variable (s1) se usa para guardar momentaneamente cada una 
                     * de las palabras que contiene el archivo de texto
                     */
                     s1 = txt.toString();
                     /**
                      *Aqui se guardan las palabras en el hashMap
                      */
                     listaPalabras.put(i, s1);
                     /**
                      * Se borra el buffer de txt
                      */
                     txt.delete(0, txt.length());
                     i++;
                  }
               //Leer el siguiente carácter
               caract = fr.read();
           }
           //Cerrar el fichero
           fr.close();

        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
   }
   public HashMap<Integer,String> getLista() 
   {
        return listaPalabras;
   }
}
