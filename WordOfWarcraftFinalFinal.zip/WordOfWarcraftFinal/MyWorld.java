import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.*;
import java.util.Random;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    char car;

    WordManager manejadorW = new WordManager();
    String palabra = manejadorW.getPalabra();
    private Jugador j2D = new Jugador();
    String sTemp;
    Integer v;
    Vidas v3;
    Vidas v2;
    Vidas v1;
    int level;
    int i = 25;
    int j = 20;
    int icont = 0;
    int icont2 = 0;
    Character cTemp;
    
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld(int level)
    {
        super(1080, 600, 1);
        this.level = level;
        addObject(j2D, 65, 539);
        i = 25;
        j = 20;
        icont = 0;
        icont2 = 0;
        sTemp = palabra;

        String cade;
        v3 = new Vidas("3");
        v2 = new Vidas("2");
        v1 = new Vidas("1");
        //int intr = 0;
        
        
        switch(level)
        {
            case 1:
                    fileRead("Level1.txt");
                    break;
            case 2:
                    fileRead("Level2.txt");
                    break;
            case 3:
                    fileRead("Level3.txt");
                    break;
        }
    }

        private void fileRead2(String nivel)
    {
        
      File archivo = null;
      FileReader fr = null;
      BufferedReader br = null;

      try {
         // Apertura del fichero y creacion de BufferedReader para poder
         // hacer una lectura comoda (disponer del metodo readLine()).
         archivo = new File (nivel);
         fr = new FileReader (archivo);
         br = new BufferedReader(fr);

         // Lectura del fichero
         int linea;
         while((linea=br.read())!=-1)
            System.out.println(linea);
      }
      catch(Exception e){
         e.printStackTrace();
      }
    }
    
    private void fileRead(String nivel)
    {
        Random rand = new Random();
        StringBuffer txt = new StringBuffer();
        try
        {
           //Abrir el fichero indicado en la variable nombreFichero
           FileReader fr = new FileReader(nivel);
           //Leer el primer carácter
           //Se debe almacenar en una variable de tipo int
           int caract = fr.read();
           //Se recorre el fichero hasta encontrar el carácter -1
           //   que marca el final del fichero           
           while(caract != -1)
           {
               if((char)caract == '1')
               {
                  if(6 == rand.nextInt(10) || 4 == rand.nextInt(10))
                  {
                      if(icont2 == 2)
                      {
                          if(icont < palabra.length()-1)
                          {
                              cTemp = sTemp.charAt(0);
                              sTemp = sTemp.substring(1);
    
                              txt.append(cTemp);
                              addObject(new MuroE(cTemp, i, j),i,j);
                              
                              icont++;
                          }
                          icont2 = 0;
                      }   
                      else
                      {
                          addObject(new MuroN("wall_green"),i,j);
                          icont2++;
                      }
                  }
                  else
                  {
                      addObject(new MuroN("wall_white"),i,j);
                  }
                   i = i+52;
               }
               else
                 if((char)caract == ' ')
                 {
                     i = i+52;
                 }
                 else
                 if((char)caract == '0')
                  {
                     addObject(new Enemigo(), i, j);
                     i = i+52;
                  }
                  else
                      if((char)caract == '\n')
                      {
                         i = 25;
                         j = j+52;
                      }
               //Leer el siguiente carácter
               caract = fr.read();

            }
           //Cerrar el fichero
           fr.close();
           }
            catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        
        
      
    }
    
    
    public void act()
    {
       v = j2D.getVidas();
       Character temp;
       int array3[];
       array3 = new int[2];
       int iYouWin = 0;
       Integer iCnL = -1;
       
       showText("Orig "+palabra,430,20);

        if(level == 4)
        {
           // v = 0;
            Greenfoot.setWorld(new Ganaste());
        }
        switch ( v ) 
        {
          case 3:
                addObject(v3, 730, 20);
                temp = j2D.getChar();
                array3 = j2D.getPosB();
                addObject(new MuroN("wall_red"),array3[0],array3[1]);
                showText("Letra "+temp.toString(),630,20);
                iCnL = j2D.getBandW();
               // showText("Letra "+poschar.toString(),550,20);
               break;
          case 2:
                removeObject(v3);
                addObject(v2, 730, 20);
                temp = j2D.getChar();
                array3 = j2D.getPosB();
                addObject(new MuroN("wall_red"),array3[0],array3[1]);
                showText("Letra "+temp.toString(),630,20);
                iCnL = j2D.getBandW();
                
              //  showText("Letra "+poschar.toString(),550,20);
               break;
          case 1:
                removeObject(v2);
                addObject(v1, 730, 20);
                temp = j2D.getChar();
                array3 = j2D.getPosB();
                addObject(new MuroN("wall_red"),array3[0],array3[1]);
                showText("Letra "+temp.toString(),630,20);
                iCnL = j2D.getBandW();
               // showText("Letra "+poschar.toString(),550,20);
               break;
          case 0:
                removeObject(v1);
                removeObject(j2D);
                showText("GAME OVER", 540, 300);
                Greenfoot.setWorld(new StarScreen());
                break;
        }
        Integer s = palabra.length()-1;
        showText(s.toString(),550,20);
        showText(iCnL.toString(),580,20);
        
        if(iCnL == palabra.length()-1)
        {
                Greenfoot.setWorld(new MyWorld(level+1));
        }
    }
    public void diezSeg()
    {
        int segundos;
        for(segundos = 0; segundos <= 10; segundos++)
        {
            delaySegundo();
        }
    }   
    
    private static void delaySegundo()
    {
        try
        {
            Thread.sleep(1000);
        }
        catch(InterruptedException e){}
    }
}