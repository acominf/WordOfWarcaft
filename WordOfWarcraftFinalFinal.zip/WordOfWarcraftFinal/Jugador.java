import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Jugador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugador extends Personaje
{
    private int pun;
    private int iVid;
    private char cLet;
    int iContW = 0;
    int array2[];
    protected Vidas vidas;
    private GreenfootImage R1;
    private GreenfootImage R3;
    private GreenfootImage I1;
    private GreenfootImage I3;
    private GreenfootImage front;
    private GreenfootImage back;

    
     public Jugador(){
         pun = 0;
         iVid = 3;
         R1 = new GreenfootImage("1d.png");
         R3 = new GreenfootImage("3d.png");
         I1 = new GreenfootImage("1i.png");
         I3 = new GreenfootImage("3i.png");
         front = new GreenfootImage("espalda2.png");
         back = new GreenfootImage("frente2.png");
         array2 = new int[2];
    }
    
    public void sonido(){
        if(canSee(Word.class)){
            eat(Word.class);
            Greenfoot.playSound("slurp.wav");
            pun++;
        }
    }
    
    public void act()
    {
  
        sonido();
        presiona();
        enPeligro();
    }
   
    public void presiona()
    {
        if(Greenfoot.isKeyDown("left"))
        {
            mLeft();
            if(isTouching(Muro.class))
            {
                mRight();
            }
        }
        
        if(Greenfoot.isKeyDown("right"))
        {
            mRight();
            if(isTouching(Muro.class))
            {
                mLeft();
            }
        }
        
        if(Greenfoot.isKeyDown("up"))
        {
            mUp();
            
            if(isTouching(Muro.class))
            {
                mDown();
            }
        }
        if(Greenfoot.isKeyDown("down"))
        {
            mDown();
            
            if(isTouching(Muro.class))
            {
                mUp();
            }
        }
    }
    
    public void mLeft()
    {
        if(getRotation() != 0)
                setRotation(0);
           
            if(getImage() == I1)
            {
                setImage(I3);
            }
            else
            {
                setImage(I1);
            }        
        move(-5);
    }
    
    public void mRight()
    {
        if(getRotation() != 0)
                setRotation(0);
                
        if(getImage() == R1)
        {
             setImage(R3);
        }
        else
        {
             setImage(R1);
        } 
        move(5);
    }
    
    public void mUp()
    {
        if(getRotation() != 0)
                setRotation(0);
                
        setImage(front);
        setRotation(-90);
        
        move(5);  
    }
    
    public void mDown()
    {
        if(getRotation() != 0)
                setRotation(0);
            
        setImage(back);
        setRotation(90);
        
        move(5);
    }
    
    
    public char getChar()
    {
        List <MuroE> lBloques = getObjectsInRange(80, MuroE.class);
        if(lBloques.size() > 0)
        {
            cLet = lBloques.get(0).getCar();
                getPosB();
                eat(MuroE.class);
        }

        return cLet;
    }
    
    
    public int[] getPosB()
    {
        List <MuroE> lBloques = getObjectsInRange(80, MuroE.class);
        if(lBloques.size() > 0)
        {
            array2 = lBloques.get(0).getArr();
            getWorld().removeObject(lBloques.get(0));
            iContW++;
        }
        return array2;
    }
    public int getBandW()
    {
        return iContW;
    }
    
    public void enPeligro()
    {
        if(canSee(Enemigo.class))
        {
          setLocation(65,539);
          iVid--;
        }
    }
    
    public int getVidas()
    {
        return iVid;
    }
}
