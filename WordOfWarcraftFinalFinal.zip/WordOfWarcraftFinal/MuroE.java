import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MuroE here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MuroE extends Muro
{
    private char car;
    int array1[];
    /**
     * Act - do whatever the MuroE wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public MuroE(char car, int i, int j)
    {
        super();
        this.car = car;
        array1 = new int[2];
        array1[0] = i;
        array1[1] = j;
        
    }
    
    public MuroE()
    {
        super();
        car = '\0';
        
    }
    
    public char getCar()
    {
        return car;
    }
    
    public int[] getArr()
    {
        return array1;
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
