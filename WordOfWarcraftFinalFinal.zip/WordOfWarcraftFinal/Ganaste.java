import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Win here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ganaste extends World
{
    int seg = 0;
    int band = 0;
        
    /**
     * Constructor for objects of class Win.
     * 
     */
    public Ganaste()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1080, 600, 1);

        //Greenfoot.setWorld(new StarScreen());
    }
    
     public void act()
    {
        showText("Preciona ENTER para regresar al menu ",200,20);
        if(Greenfoot.isKeyDown("enter"))
        {
            Greenfoot.setWorld(new StarScreen());
        }
        
    }
    
}